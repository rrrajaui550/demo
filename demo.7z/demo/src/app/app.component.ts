import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  columnDefs = [
      { field: 'PatientName',sortable: true, filter: true, rowDrag: true, pinned: 'left',
      lockPinned: true,
      cellClass: 'lock-pinned' },
      { field: 'UHID' ,sortable: true, filter: true},
      { field: 'ContactNumber',sortable: true, filter: true },
      { field: 'Appointment',sortable: true, filter: true },
      { field: 'Consultation',sortable: true, filter: true },
      { field: 'Status',sortable: true, filter: true }
  ];

  rowData = [
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},  { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},  { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},  { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
      { PatientName: 'Lindsey Stroud', UHID: '#3456346435', ContactNumber: 9876022222,Appointment:'13-08-20', Consultation:'First',Status:'Inprogress'},
  ];

}
